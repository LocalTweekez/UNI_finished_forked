#ifndef ADDCONTACT_H
#define ADDCONTACT_H
using namespace std;

void addContact();

#endif


