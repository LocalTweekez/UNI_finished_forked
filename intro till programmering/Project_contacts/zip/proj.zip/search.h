#ifndef SEARCH_H
#define SEARCH_H

using namespace std;

int search();

#endif
