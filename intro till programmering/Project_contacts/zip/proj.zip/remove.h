#ifndef REMOVE_H
#define REMOVE_H

using namespace std;

int remove();

#endif