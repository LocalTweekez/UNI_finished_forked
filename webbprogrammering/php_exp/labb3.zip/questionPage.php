<?php include("includes/config.php"); ?>
<?php
$page_title = "questions";
include("includes/header.php");
include("includes/navbar.php");
include("includes/frågor.php");
include("includes/footer.php");


?>