<?php include("includes/config.php"); ?>
<?php
$page_title = "information";
include("includes/header.php");
include("includes/navbar.php");
include("includes/CreateInfoBox.php");
createInfoBox();
include("includes/footer.php");
?>
