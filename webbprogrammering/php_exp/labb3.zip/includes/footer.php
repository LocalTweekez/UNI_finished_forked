<!-- <style>
    #mainfooter{
        margin-top: 10%;
        text-align: center;
    } -->

<!-- </style> -->

<footer id="mainfooter">
    <hr>
            <p>thank you</p>
</footer><!-- /mainfooter -->
<!-- /container -->
    

</body>
</html>