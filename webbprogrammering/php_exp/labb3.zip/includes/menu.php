<!-- <style>
   
    #menu{
        text-align: center;
        margin-top: 15%;
    }
    .card{
        
        margin: auto;
    }
    .btn{
        background-color:#78569e ;
    }
    .text{
        
       margin-bottom: 20px;
        text-align: center;
    }
</style> -->
<h1 class="text">Welcome</h1>
<h4 class="text">This is the third laboration in the webprograming course menu, login too see the content.</h4>
<div id="menu" class="container">
    
    <div class="container-fluid row menu">
        <div class="card" style="width: 25rem;">
            <img src="images/questions.jpg" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">PHP experience</h5>
                <p class="card-text">Q & A about my php experience</p><br>
                <a href="questionPage.php" class="location link btn btn-dark">See Q & A</a>
            </div>
        </div>

        <div class="card" style="width: 25rem;">
            <img src="images/info.webp" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">Information</h5>
                <p class="card-text">Just some random info</p><br>
                <a  href="informationPage.php" class="location-link btn btn-dark">See information</a>
            </div>
        </div>
        
        
    </div>
</div>

