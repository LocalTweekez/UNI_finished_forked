
<!-- <style>
    img{
        width: 48px;
    }
</style> -->
<nav class="nav navbar navbar-expand-lg navbar-dark ">
    <div>
        <a id ="homebutton" class="navbar-brand" href="startPage.php"><img src="images/home.png" alt=""></a>
    </div>
        <button class="navbar-toggler location-link" type="button" data-bs-toggle="collapse" data-bs-target="#navbarBurger" aria-controls="navbarBurger" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarBurger">
            <ul class="navbar-nav ms-auto">
                <li class="navbar-item">
                    <a class="nav-link location-link" href="">About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link location-link" href="loginPage.php">Log In</a>
                </li>
            </ul>
        </div>
    </nav>