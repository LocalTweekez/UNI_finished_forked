<?php
    $site_title = "Min webbplats";
    $divider = " | ";
    $logged_in = false;