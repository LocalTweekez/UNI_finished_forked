<div class="container" id="frågor">
    <h1><u><strong> Frågor:</strong></u></h1><br>

<h3><strong>Har du tidigare erfarenhet Av utveckling med PHP?</strong></h3>
<p>Nej PHP är ett helt nytt språk för mig.</p><br>

<h3><strong>Hur har du valt att strukturera upp dina filer och kataloger?</strong></h3>
<p>Jag valde att ha en mapp css för alla stilmallar, 
    En js mapp för all funktionalitet och javascript filer, 
    en includes där jag har alla mina PHP filer som ska includeras.
    Och även en images mapp för alla bilder och former.
</p><br>

<h3><strong>Har du följt guiden, eller skapat på egen hand?</strong></h3>
<p>Jag använde mig både av guiden samt documentationen</p><br>

<h3><strong>Har du gjort några förbättringar eller vidareutvecklingar av guiden (om du följt denna)?</strong></h3>
<p>Jag har skapat egen struktur och har egna ideer om hur jag ska lösa problemet,
     guiden vara bara en inspiration när jag fastnade.</p><br>

<h3><strong>Vilken utvecklingsmiljö har du använt för uppgiften (Editor, webbserver etcetera)?</strong></h3>
<p>Jag använder mig av VS code text editor och har använt XAMPP för hosta en lokal server</p><br>

<h3><strong>Har något varit svårt med denna uppgift?</strong></h3>
<p>Det var svårt att förstå vad PHP andvänds till vad meningen med språket var och hur jag skulle lära mig syntaxen.</p><br>
    
</div>