<?php
include("includes/config.php");
$page_title="login page";
include("includes/header.php");
include("includes/loginDiv.php");
?>