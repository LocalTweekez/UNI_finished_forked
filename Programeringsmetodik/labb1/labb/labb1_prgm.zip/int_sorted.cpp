#include "int_sorted.h"
#include "iostream"



int_sorted::int_sorted(const int* source, size_t size): 
	buf(int_buffer(source, size)) {


};
size_t int_sorted::size() const {

	return buf.size();
};

void int_sorted::insert(int value) {

	size_t temp = size();
	buf = int_buffer(buf.begin(), temp + 1);
	buf[temp] = value;
	


};

int_buffer int_sorted::getBuf()
{
	return buf;
}

bool int_sorted::checkIfSorted(){
	int* next = buf.begin();
	int a = *buf.begin();
	while (++next != buf.end()) {
		int b = *next;
		if (a > b) {
			std::cout << "is not sorted" << std::endl;
			return false;
		}
		a = b;
	}
	std::cout << "sorted!" << std::endl;
	return true;
}


void int_sorted::print(){
	buf.print();
}



int_sorted int_sorted::sort(const int* begin, const int* end){
	if (begin == end) return int_sorted(nullptr, 0);

	if (begin == end - 1) return int_sorted(begin, 1);
	
	ptrdiff_t half = (end - begin) / 2;

	const int* mid = begin + half;

	return sort(begin, mid).merge(sort(mid, end));
}





const int* int_sorted::begin() const {
	return buf.begin();
};

const int* int_sorted::end() const {
	return buf.end();
};



int_sorted int_sorted::merge(const int_sorted& merge_with) const {
	size_t cSize = this->size() + merge_with.size();
	size_t index = 0;
	int_buffer c = int_buffer(cSize);
	int_sorted C(c.begin(), cSize);
	auto A = this->begin();
	auto B = merge_with.begin();


	while (A != this->end() && B != merge_with.end()) {
		int a = *A;
		int b = *B;
		if (a < b) {
			C.buf[index] = a;
			A++;
		}
		else {
			C.buf[index] = b;
			B++;
		}
		index++;
	}
	while (A != this->end()) {
		int a = *A;
		C.buf[index] = a;
		index++;
		A++;
	}
	while (B != merge_with.end()) {
		int b = *B;
		C.buf[index] = b;
		index++;
		B++;
	}
	return C;
};

