#include "mbed.h"
#include "C12832.h"
#include "treedude.h"


C12832 LCD(p5,p7,p6,p8,p11);
DigitalIn down(p15);
DigitalIn up(p12);
DigitalIn left(p13);
DigitalIn right(p16);

float x = 0;
float y = 0;


int main(){
    while(1){
        // Clear screen
        LCD.cls();

        // When the joystick is moved in a certain direction,
        //the caracter moves to that direction with a change of 0.2
        //the character moves until the pixel limits
        if(up==1 && y< 32) y+=0.2;
        if(down==1 && y >0) y-=0.2;
        if(right==1&& x <128) x+=0.2;
        if(left==1 && x>0) x-=0.2;

        // Print the bitmap to LCD
        LCD.print_bm(bitmTreedude,x,y);
        LCD.copy_to_lcd();
        }
}