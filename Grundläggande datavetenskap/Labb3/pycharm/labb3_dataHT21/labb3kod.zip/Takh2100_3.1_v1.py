#! python3
# filnamn: Takh2100_3.1_v1.py
# Skrivet av: Taha Khudher
# Skapat datum: 2021-10-04
# Senast ändrat: 2021-10-07
# Kurs: Grundläggande Datavetenskap
# Handledare: Martin Kjellqvist
# Beskrivning:



i= 0
while( i < 10 ):
    print( i )
    i =i + 1
print( "SLUT",i )
