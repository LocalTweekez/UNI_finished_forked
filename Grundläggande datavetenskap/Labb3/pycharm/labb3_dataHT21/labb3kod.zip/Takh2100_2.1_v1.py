#! python3
# filnamn: Takh2100_2.1_v1.py
# Skrivet av: Taha Khudher
# Skapat datum: 2021-10-04
# Senast ändrat: 2021-10-07
# Kurs: Grundläggande Datavetenskap
# Handledare: Martin Kjellqvist
# Beskrivning: 



Tal = int(input("mata en ett tal: "))
if Tal % 2 == 0:

    print("Talet är jämnt")
else:
    print("Talet är udda")
