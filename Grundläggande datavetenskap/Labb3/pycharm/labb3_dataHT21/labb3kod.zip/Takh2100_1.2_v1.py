#! python3
# filnamn: Takh2100_1.2_v1.py
# Skrivet av: Taha Khudher
# Skapat datum: 2021-10-04
# Senast ändrat: 2021-10-07
# Kurs: Grundläggande Datavetenskap
# Handledare: Martin Kjellqvist
# Beskrivning: Värden tilldeles till variabler benämda från a-e
# sedan tilldelas värden till andra variabler och aderas .

a= 1
b = "Ett"
c = 5.2
d = "5.2"
e = "3"

aa = "Antal" + str(a)
bb = "Antal" + b
cc = "Antal" + str(c)
dd = "Antal" + d
ee = "Antal" + e

print( aa )
print( bb )
print( cc )
print( dd )
print( ee )

aa = 10 + a
bb = str(10) + b
cc = 10 + c
dd = 10 + float(d)
ee = 10 + int(e)

print( aa )
print( bb )
print( cc )
print( dd )
print( ee )